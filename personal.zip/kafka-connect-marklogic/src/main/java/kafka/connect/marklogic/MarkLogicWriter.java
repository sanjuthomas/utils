package kafka.connect.marklogic;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.kafka.connect.sink.SinkRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.marklogic.client.DatabaseClient;
import com.marklogic.client.DatabaseClientFactory;
import com.marklogic.client.DatabaseClientFactory.Authentication;
import com.marklogic.client.document.TextDocumentManager;
import com.marklogic.client.io.StringHandle;

import kafka.connect.marklogic.sink.MarkLogicSinkConfig;

/**
 * 
 * @author Sanju Thomas
 *
 */
public class MarkLogicWriter implements Writer {
	
	private static final Logger logger = LoggerFactory.getLogger(MarkLogicWriter.class);
	private static final String URL = "url";
	private static final String DOCUMENT = "document";
	private final TextDocumentManager manager;
	protected final DatabaseClient client;

	public MarkLogicWriter(final Map<String, String> config) {
		client = DatabaseClientFactory.newClient(config.get(MarkLogicSinkConfig.CONNECTION_HOST),
				Integer.valueOf(config.get(MarkLogicSinkConfig.CONNECTION_PORT)),
				config.get(MarkLogicSinkConfig.CONNECTION_USER),
						config.get(MarkLogicSinkConfig.CONNECTION_PASSWORD), Authentication.DIGEST);
		manager = client.newTextDocumentManager();
	}

	public void write(final Collection<SinkRecord> recrods) {

		recrods.forEach(r -> {
			logger.debug("received value {}, and collection {}", r.value(), r.topic());
			final Map<?, ?> v = new LinkedHashMap<>((Map<?, ?>) r.value());
			try {
				manager.write(url(v), handle(v));
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
				throw new RuntimeException(e);
			}
		});
	}

	protected String url(final Map<?, ?> valueMap) {
		return valueMap.get(URL) == null ? UUID.randomUUID().toString() : valueMap.get(URL).toString();
	}

	protected StringHandle handle(final Map<?, ?> valueMap) {
		return new StringHandle((String) valueMap.get(DOCUMENT));
	}
}
