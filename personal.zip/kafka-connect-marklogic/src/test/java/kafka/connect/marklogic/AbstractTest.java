package kafka.connect.marklogic;

import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import com.marklogic.client.DatabaseClient;
import com.marklogic.client.DatabaseClientFactory;
import com.marklogic.client.DatabaseClientFactory.Authentication;
import com.marklogic.client.document.DocumentPage;
import com.marklogic.client.document.XMLDocumentManager;
import com.marklogic.client.io.StringHandle;

import kafka.connect.marklogic.beans.QuoteRequest;
import kafka.connect.marklogic.sink.MarkLogicSinkConfig;

/**
 * 
 * @author Sanju Thomas
 *
 */
public abstract class AbstractTest {
    
  
	    protected final Map<String, String> conf = new HashMap<>();
	    protected XMLDocumentManager manager;
	    protected DatabaseClient client;

	    public void setup(){

	        conf.put(MarkLogicSinkConfig.CONNECTION_HOST, "localhost");
	        conf.put(MarkLogicSinkConfig.CONNECTION_PORT, "8000");
	        conf.put(MarkLogicSinkConfig.CONNECTION_USER, "admin");
	        conf.put(MarkLogicSinkConfig.CONNECTION_PASSWORD, "admin");
	        conf.put(MarkLogicSinkConfig.BATCH_SIZE, "100");
	        conf.put(MarkLogicSinkConfig.WRITER_IMPL, MarkLogicWriter.class.getCanonicalName());
	        conf.put(MarkLogicSinkConfig.RETRY_BACKOFF_MS, "100");
	        conf.put(MarkLogicSinkConfig.MAX_RETRIES, "10");
	        conf.put("topics", "trades");
	        
	        client = DatabaseClientFactory.newClient("localhost", 8000, "admin", "admin", Authentication.DIGEST);
	        manager = client.newXMLDocumentManager();
	    }

	    public QuoteRequest find(String url) throws JAXBException{
	    	
	    	JAXBContext jaxbContext = JAXBContext.newInstance(QuoteRequest.class);
	    	Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
	        
	        final DocumentPage documentPage = manager.read(url);
	        if(documentPage.hasNext()){
	        	StringHandle handle = new StringHandle();
	            handle = documentPage.nextContent(handle);
	            return (QuoteRequest) unmarshaller.unmarshal(new StringReader(handle.get()));
	        }
	        return null;
	    }
	    
	    public void delete(String url){
	        manager.delete(url);
	    }

}
