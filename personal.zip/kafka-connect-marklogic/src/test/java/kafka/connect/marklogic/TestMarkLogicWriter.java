package kafka.connect.marklogic;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.io.StringWriter;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.http.client.ClientProtocolException;
import org.apache.kafka.connect.sink.SinkRecord;
import org.junit.Before;
import org.junit.Test;

import kafka.connect.marklogic.beans.Account;
import kafka.connect.marklogic.beans.Client;
import kafka.connect.marklogic.beans.QuoteRequest;

/**
 * 
 * @author Sanju Thomas
 *
 */
public class TestMarkLogicWriter extends AbstractTest{
	
	private Writer writer;

	@Before
	public void setup(){
	    super.setup();
		writer = new MarkLogicWriter(super.conf);
	}
	
	@Test
	public void shouldWrite() throws ClientProtocolException, IOException, URISyntaxException, JAXBException{
		
	    final List<SinkRecord> documents = new ArrayList<SinkRecord>();
        final QuoteRequest quoteRequest1 = new QuoteRequest("Q2", "IBM", 100, new Client("C2", new Account("A2")), new Date());
        
        JAXBContext jaxbContext = JAXBContext.newInstance(QuoteRequest.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        
        StringWriter sw = new StringWriter();	
        jaxbMarshaller.marshal(quoteRequest1, sw);
        String xmlString = sw.toString();
        
        Map<String, Object> documentMap = new LinkedHashMap<>();
        documentMap.put("url", "test1.xml");
        documentMap.put("document", xmlString);
        
        documents.add(new SinkRecord("topic", 1, null, null, null, documentMap, 0));
        writer.write(documents);
		
		 
        QuoteRequest qr = super.find("test1.xml");
        assertEquals("IBM", qr.getSymbol());
        super.delete("test1.xml");
	}
}

