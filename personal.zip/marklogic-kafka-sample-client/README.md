# marklogic-kafka-sample-client

A set of example clients to produce messages that will be eventually stored as json in MarkLogic.

Please refer to https://github.com/sanjuthomas/kafka-connect-marklogic for the Kafka Connect MarkLogic.