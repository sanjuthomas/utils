package marklogic.kafka.client.impl;

import java.io.StringWriter;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import marklogic.kafka.client.beans.Account;
import marklogic.kafka.client.beans.Client;
import marklogic.kafka.client.beans.QuoteRequest;

public class XMLMessageProducer {
	
	private static final ObjectMapper MAPPER = new ObjectMapper();
	
	 public static void main(String[] args) throws JAXBException {
	      
	        String [] symbols = new String [] {"ABB", "AAV", "AAPL", "BABA", "BAK", "BANC", "DAL", "DBD", "DBL", "RACE", "RATE", "RCG", "YELP", "YUME", "ZPIN"};

	        String topicName = "quote-request";
	        Properties props = new Properties();
	        props.put("bootstrap.servers", "localhost:9092");
	        props.put("acks", "all");
	        props.put("retries", 3);
	        props.put("batch.size", 100);
	        props.put("linger.ms", 1);
	        props.put("buffer.memory", 2048);
	        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
	        props.put("value.serializer", "org.apache.kafka.connect.json.JsonSerializer");
	        
	        JAXBContext jaxbContext = JAXBContext.newInstance(QuoteRequest.class);
	        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
	        
	        Producer<String, JsonNode> producer = new KafkaProducer<String, JsonNode>(props);
	        for (int i = 0; i < 1; i++){
	            final Account account = new Account("A" + i);
	            final Client client = new Client("C" + i, account);
	            final QuoteRequest quoteRequest = new QuoteRequest("Q" + i, symbols[ThreadLocalRandom.current().nextInt(0, 14)], 
	                    ThreadLocalRandom.current().nextInt(1, 100 + 1), client, new Date());
	            
	            StringWriter sw = new StringWriter();	
	            jaxbMarshaller.marshal(quoteRequest, sw);
	            String xmlString = sw.toString();
	            
	            Map<String, Object> documentMap = new LinkedHashMap<>();
	            documentMap.put("url", quoteRequest.getUrl());
	            documentMap.put("document", xmlString);
	            
	            final JsonNode jsonNode = MAPPER.valueToTree(documentMap);
	            producer.send(new ProducerRecord<String, JsonNode>(topicName, jsonNode));
	        }
	        producer.flush();
	        producer.close();
	        System.out.println("Message sent successfully");
	    }

}
